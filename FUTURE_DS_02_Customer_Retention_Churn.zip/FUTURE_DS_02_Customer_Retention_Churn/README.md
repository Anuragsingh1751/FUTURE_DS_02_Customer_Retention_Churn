# Telco Customer Retention & Churn Analysis

## Project 2 — Data Science & Analytics

This project analyzes customer churn and retention behavior using a cleaned Telco Customer Churn dataset.

### Project Objectives
- Measure overall customer churn and retention.
- Identify high-risk customer segments.
- Compare churn across contract types.
- Analyze churn by tenure, internet service, payment method, and monthly charge group.
- Provide practical customer-retention recommendations.

### Key Results
- Total Customers: 7,043
- Churned Customers: 1,869
- Retained Customers: 5,174
- Overall Churn Rate: 26.54%

### Dashboard
The final dashboard is available in:
`dashboard/Telco_Customer_Retention_Churn_Dashboard.xlsx`

The dashboard includes:
- KPI cards
- Stayed vs Churned donut chart
- Contract churn-rate bar chart
- Tenure retention vs churn chart
- Internet-service churn-rate bar chart
- Charge-group customer mix donut chart
- Retention-rate trend
- High-risk segment highlight
- Business insights and recommendations

### High-Risk Segment
Month-to-month + 0–12 Months + Fiber optic customers show the strongest churn risk in the analyzed segment.

### Tools
- Microsoft Excel
- Pivot-table based analysis
- Data cleaning
- Dashboard visualization
- Business analytics

### Folder Structure
- `data/raw` — source dataset
- `data/cleaned` — cleaned dataset
- `dashboard` — final dashboard
- `analysis` — supporting analysis
- `documentation` — project documentation
- `screenshots` — dashboard screenshots
